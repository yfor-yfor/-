#!/bin/bash
while true; do
    sleep 10
    if ! pgrep -x sockserver > /dev/null; then
        pkill -9 sockserver
        cd /home/ctf && ./sockserver &
    fi
done

