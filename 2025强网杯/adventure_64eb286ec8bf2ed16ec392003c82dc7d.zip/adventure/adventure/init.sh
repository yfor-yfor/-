#!/bin/sh

# DO NOT DELETE
./start.sh
/etc/init.d/xinetd start
sleep infinity

