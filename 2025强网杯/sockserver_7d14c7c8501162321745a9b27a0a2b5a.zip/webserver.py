#!/usr/bin/env python3
import os
import sys
import time
import socket
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse

class CustomHTTPRequestHandler(BaseHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        # 设置web根目录
        self.web_root = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'web')
        super().__init__(*args, **kwargs)
    
    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        clean_path = path.split('?')[0].split('#')[0]
        if clean_path == '/' or clean_path == '/index.html':
            self.serve_file('index.html')
        elif clean_path == '/flag.html':
            self.serve_file('flag.html')
        else:
            self.send_error(404, "Page not found")
    
    def serve_file(self, filename):
        try:
            allowed_files = ['index.html', 'flag.html']
            
            if filename not in allowed_files:
                self.send_error(404, "Page not found")
                return
            file_path = os.path.join(self.web_root, filename)
            file_path = os.path.abspath(file_path)
            web_root_abs = os.path.abspath(self.web_root)
            if not file_path.startswith(web_root_abs):
                self.send_error(403, "Forbidden")
                return
            with open(file_path, 'rb') as f:
                content = f.read()
            
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)
            
        except FileNotFoundError:
            self.send_error(404, "Page not found")
        except Exception as e:
            self.send_error(500, "Internal server error")
    
    def log_message(self, format, *args):
        timestamp = time.strftime('%Y-%m-%d %H:%M:%S')

def start_web_server(host='127.0.0.1', port=8081):
    
    try:
        server = HTTPServer((host, port), CustomHTTPRequestHandler)
        
        server.serve_forever()
        
    except KeyboardInterrupt:
        server.shutdown()
    except Exception as e:
        sys.exit(1)

if __name__ == '__main__':
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.bind(('127.0.0.1', 8081))
        sock.close()
    except OSError:
        sys.exit(1)
    
    start_web_server()
