# README

## Build

```
docker build -t babyjs .
```

## Run

```
docker run -e FLAG=flag{fake_flag} -it --rm --name babyjs -p 7123:70 babyjs
```
