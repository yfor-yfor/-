#!/bin/sh

cd /home/ctf && python3 webserver.py &
sleep 2
cd /home/ctf && ./sockserver &
sleep 2
cd /home/ctf && ./monitor.sh &
# 保持容器运行
sleep infinity
