set -e
while [ true ]; do
	socat -dd TCP4-LISTEN:9000,fork,reuseaddr EXEC:'/chall',pty,echo=0,rawer,iexten=0
done